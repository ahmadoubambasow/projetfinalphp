<?php 

if(!$_SESSION['password']){
    header('location:login.php');
};

?>